# KANG AI V1.0

Experimental Thai-language command-line AI assistant by Inventor Lab.

## Requirements
- Python 3
- A local `llama.cpp` server exposing an OpenAI-compatible chat completions endpoint

## Run
Start your local model server first, then run:

```bash
python kang.py
```

Default API endpoint: `http://127.0.0.1:8080/v1/chat/completions`

To exit, type `exit`.

## Notes
- This is an experimental prototype and has not been verified against a running model server in this package.
- The `hits` parameter supports passing knowledge-base results from another component; the included CLI currently passes an empty list.
- Do not commit model weights, private documents, credentials, or secrets.
