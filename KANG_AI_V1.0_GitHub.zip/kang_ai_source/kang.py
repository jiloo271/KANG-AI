API = "http://127.0.0.1:8080/v1/chat/completions"
import urllib.request
import urllib.error
import json
def ask_qwen(question, hits):
    # ตั้งค่าบทบาทของ KANG AI
    identity = (
        "คุณคือ KANG AI ผู้ช่วย AI ส่วนตัว "
        "ของ ป๋อ จิรายุ แห่ง porhacg\n"
        "ตอบเป็นภาษาไทยเป็นหลัก\n"
        "ตอบให้ตรงคำถาม เข้าใจง่าย และมีประโยชน์\n"
        "สามารถตอบคำถามทั่วไปได้ แม้ไม่มีข้อมูลในฐานความรู้\n"
        "ห้ามแต่งข้อมูล แหล่งอ้างอิง หรืออ้างว่าอ่านไฟล์ "
        "หากไม่ได้อ่านจริง\n"
        "หากไม่แน่ใจ ให้บอกอย่างตรงไปตรงมา"
    )

    # เตรียมเอกสารจากฐานความรู้
    if hits:
        context_parts = []

        for d in hits:
            source = d.get("source", "ไม่ทราบชื่อไฟล์")
            content = d.get("text", "")

            if content.strip():
                context_parts.append(
                    f"[ไฟล์: {source}]\n{content}"
                )

        context = "\n\n".join(context_parts)

        if context.strip():
            system = (
                identity
                + "\n\nคำแนะนำในการใช้ฐานความรู้:\n"
                + "1. ใช้เอกสารเมื่อเกี่ยวข้องกับคำถาม\n"
                + "2. ใช้ความรู้เดิมของโมเดลเสริมได้\n"
                + "3. ถ้าเอกสารไม่มีคำตอบ ให้ตอบจากความรู้เดิม "
                "เมื่อมีข้อมูลเพียงพอ\n"
                + "4. แยกให้ชัดเจนระหว่างข้อมูลในเอกสาร "
                "กับความรู้ทั่วไป\n"
                + "5. อย่าฝืนใช้เอกสารที่ไม่เกี่ยวข้อง\n\n"
                + "เอกสารที่ระบบค้นพบ:\n"
                + context


            )
        else:
            system = identity
    else:
        # ไม่พบเอกสาร ให้ Qwen ตอบจากความรู้เดิม
        system = (
            identity
            + "\n\nไม่มีเอกสารจากฐานความรู้ที่ส่งมา "
            "ให้ตอบจากความรู้เดิมของโมเดลได้ตามปกติ\n"
            + "หากเป็นเรื่องที่ไม่รู้หรือข้อมูลไม่เพียงพอ "
            "ให้แจ้งข้อจำกัดอย่างตรงไปตรงมา"
        )

    # สร้างคำขอไปยัง llama.cpp server
    payload = {
        "messages": [
            {
                "role": "system",
                "content": system
            },
            {
                "role": "user",
                "content": question
            }
        ],
        "temperature": 0.3,
        "max_tokens": 700,
        "stream": False
    }

    req = urllib.request.Request(
        API,
        data=json.dumps(
            payload,
            ensure_ascii=False
        ).encode("utf-8"),
        headers={
            "Content-Type": "application/json"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(
            req,
            timeout=180
        ) as response:
            raw = response.read().decode("utf-8")

        data = json.loads(raw)

        # ตรวจสอบคำตอบจากโมเดล
        choices = data.get("choices", [])

        if not choices:
            return (
                "KANG AI: ไม่ได้รับคำตอบจาก Qwen "
                "กรุณาตรวจสอบโมเดลและ llama.cpp server"
            )

        answer = (
            choices[0]
            .get("message", {})
            .get("content", "")
        )

        if not answer or not answer.strip():
            return "KANG AI: โมเดลส่งคำตอบว่างกลับมา"

        return answer.strip()

    except urllib.error.HTTPError as e:
        detail = e.read().decode(
            "utf-8", errors="replace"
        )
        return (
            f"KANG AI: Server แจ้ง HTTP {e.code}\n"
            f"{detail[:1000]}"
        )

    except urllib.error.URLError as e:
        return (
            "KANG AI: เชื่อมต่อ llama.cpp server ไม่ได้\n"
            f"รายละเอียด: {e.reason}\n"
            "ตรวจสอบว่า server เปิดอยู่ที่ API หรือไม่"
        )

    except json.JSONDecodeError:
        return "KANG AI: อ่านข้อมูลตอบกลับจาก server ไม่สำเร็จ"

    except TimeoutError:
        return (
            "KANG AI: รอคำตอบนานเกินไป "
            "ลองถามใหม่หรือใช้คำถามที่สั้นลง"
        )

    except Exception as e:
        return f"KANG AI: เกิดข้อผิดพลาด: {e}"


def main():
    print("=" * 40)
    print("       KANG AI V1.0")
    print("  Personal AI by porhacg")
    print("=" * 40)
    print("พิมพ์คำถามเพื่อคุยกับ AI")
    print("พิมพ์ exit เพื่อออกจากโปรแกรม")
    print()

    while True:
        try:
            question = input("คุณ: ").strip()

            if not question:
                continue

            if question.lower() in ("exit", "quit", "ออก"):
                print("KANG AI: แล้วพบกันใหม่!")
                break

            print("\nKANG AI กำลังคิด...\n")

            answer = ask_qwen(question, [])

            print("KANG AI:", answer)
            print()

        except KeyboardInterrupt:
            print("\nKANG AI: ปิดโปรแกรมแล้ว")
            break


if __name__ == "__main__":
    main()
